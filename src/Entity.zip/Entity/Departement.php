<?php

namespace App\Entity;

use App\Repository\DepartementRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=DepartementRepository::class)
 */
class Departement
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $codeDepartement;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $libelleDepartement;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCodeDepartement(): ?string
    {
        return $this->codeDepartement;
    }

    public function setCodeDepartement(string $codeDepartement): self
    {
        $this->codeDepartement = $codeDepartement;

        return $this;
    }

    public function getLibelleDepartement(): ?string
    {
        return $this->libelleDepartement;
    }

    public function setLibelleDepartement(string $libelleDepartement): self
    {
        $this->libelleDepartement = $libelleDepartement;

        return $this;
    }
}
